from pathlib import Path, PurePosixPath, PureWindowsPath
import json
import shutil
import subprocess
import tempfile
import unittest
from urllib.parse import unquote, urlsplit
from dsh_setup import DshPluginChange, updated_patch, BEGIN, END

class DshSetupTests(unittest.TestCase):
    def test_patch_preserves_user_settings_and_idempotence(self):
        text='# custom\n- id: mine\n  config:\n    value: yes\n'
        a=updated_patch(text,Path('/test/plugin.mjs'))
        self.assertTrue(a.startswith(text));self.assertEqual(a.count(BEGIN),1)
        self.assertEqual(updated_patch(a,Path('/test/plugin.mjs')),a)
        self.assertEqual(updated_patch(a),text)
    def test_empty_list(self):
        self.assertFalse(updated_patch('[]',Path('/x')).startswith('[]'))
    def test_commented_empty_list_and_uninstall(self):
        text = '# own comments\n[]\n'
        a = updated_patch(text, Path('/x'))
        self.assertNotIn('\n[]\n', a)
        self.assertEqual(updated_patch(a), text)

    def test_malformed_block_fails(self):
        with self.assertRaises(ValueError):updated_patch(BEGIN,Path('/x'))
    def test_apply_and_rollback_preserve_bytes(self):
        with tempfile.TemporaryDirectory() as t:
            home=Path(t);support=home/'support';p=home/'.dsh/profiles/desktop/cordis.patch.yml';p.parent.mkdir(parents=True);p.write_bytes(b'# user\n[]\n')
            src=home/'source.mjs';src.write_text('export default ()=>{}')
            change=DshPluginChange(home,support,home/'backup',src)
            change.apply();self.assertTrue(change.plugin.exists());change.rollback()
            self.assertEqual(p.read_bytes(),b'# user\n[]\n');self.assertFalse(change.plugin.exists())

    def test_windows_path_bom_and_crlf_preserve_user_configuration(self):
        text = '\ufeff# 用户配置\r\n- id: mine\r\n  config:\r\n    value: yes\r\n'
        plugin = PureWindowsPath(r'C:\Users\小花用户\AppData\Local\RotatingFlower\dsh\flower-observer.mjs')
        updated = updated_patch(text, plugin)
        self.assertTrue(updated.startswith(text))
        self.assertNotIn('\n', updated.replace('\r\n', ''))
        name = next(line.split('name: ', 1)[1] for line in updated.splitlines() if 'name: ' in line)
        uri = json.loads(name)
        self.assertTrue(uri.startswith('file:///C:/'))
        self.assertEqual(unquote(urlsplit(uri).path), '/' + plugin.as_posix())
        self.assertEqual(updated_patch(updated, plugin), updated)
        self.assertEqual(updated_patch(updated), text)

    def test_windows_file_uri_encodes_reserved_characters_in_yaml_scalar(self):
        plugin = PureWindowsPath(r'C:\flower 用户\#100%\observer.mjs')
        updated = updated_patch('[]\n', plugin)
        name = next(line.split('name: ', 1)[1] for line in updated.splitlines() if 'name: ' in line)
        uri = json.loads(name)  # The emitted YAML double-quoted scalar is JSON-compatible.
        self.assertEqual(uri, 'file:///C:/flower%20%E7%94%A8%E6%88%B7/%23100%25/observer.mjs')
        parsed = urlsplit(uri)
        self.assertEqual(parsed.scheme, 'file')
        self.assertEqual(parsed.query, '')
        self.assertEqual(parsed.fragment, '')
        self.assertEqual(unquote(parsed.path), '/' + plugin.as_posix())

    def test_mac_file_uri_encodes_path_without_losing_fragment_characters(self):
        plugin = PurePosixPath('/Users/flower 用户/Library/Application Support/#100%/observer.mjs')
        updated = updated_patch('[]\n', plugin)
        name = next(line.split('name: ', 1)[1] for line in updated.splitlines() if 'name: ' in line)
        uri = json.loads(name)
        self.assertEqual(uri, 'file:///Users/flower%20%E7%94%A8%E6%88%B7/Library/'
                             'Application%20Support/%23100%25/observer.mjs')
        self.assertEqual(unquote(urlsplit(uri).path), str(plugin))

    def test_upgrade_replaces_legacy_windows_path_once_and_preserves_user_settings(self):
        plugin = PureWindowsPath(r'C:\Users\小花 用户\flower-observer.mjs')
        user = '\ufeff# 用户配置\r\n- id: mine\r\n'
        legacy = user + (BEGIN + '- insert:\n    - id: rotating-flower-observer\n      name: '
                         + json.dumps(str(plugin), ensure_ascii=False) + '\n' + END).replace('\n', '\r\n')
        upgraded = updated_patch(legacy, plugin)
        self.assertTrue(upgraded.startswith(user))
        self.assertIn('name: "file:///C:/', upgraded)
        self.assertEqual(upgraded.count(BEGIN.rstrip('\n')), 1)
        self.assertEqual(updated_patch(upgraded, plugin), upgraded)
        self.assertEqual(updated_patch(upgraded), user)

    @unittest.skipUnless(shutil.which('node'), 'Node required for actual ESM import')
    def test_emitted_file_uri_loads_real_module_on_current_host(self):
        with tempfile.TemporaryDirectory() as t:
            plugin = Path(t) / 'plugin 中文 #100%.mjs'
            plugin.write_text('export default "fixture loaded";\n', encoding='utf-8')
            updated = updated_patch('[]\n', plugin)
            name = next(line.split('name: ', 1)[1] for line in updated.splitlines() if 'name: ' in line)
            uri = json.loads(name)
            result = subprocess.run(
                [shutil.which('node'), '--input-type=module', '-e',
                 'const m = await import(process.argv[1]); console.log(JSON.stringify(m.default));', uri],
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True, timeout=15)
            self.assertEqual(json.loads(result.stdout), 'fixture loaded')

    def test_file_uri_upgrade_rollback_restores_legacy_patch_and_plugin_bytes(self):
        with tempfile.TemporaryDirectory() as t:
            home = Path(t)
            plugin = home / 'support/dsh/flower-observer.mjs'
            plugin.parent.mkdir(parents=True)
            plugin.write_bytes(b'old plugin')
            patch = home / '.dsh/profiles/desktop/cordis.patch.yml'
            patch.parent.mkdir(parents=True)
            legacy = ('\ufeff# keep\r\n' + (BEGIN + '- insert:\n    - id: rotating-flower-observer\n'
                      '      name: ' + json.dumps(str(plugin), ensure_ascii=False) + '\n' + END)
                      .replace('\n', '\r\n')).encode('utf-8')
            patch.write_bytes(legacy)
            source = home / 'source.mjs'
            source.write_bytes(b'new plugin')
            change = DshPluginChange(home, home / 'support', home / 'backup', source)
            change.apply()
            self.assertIn(b'name: "file:///', patch.read_bytes())
            self.assertEqual(plugin.read_bytes(), b'new plugin')
            change.rollback()
            self.assertEqual(patch.read_bytes(), legacy)
            self.assertEqual(plugin.read_bytes(), b'old plugin')

    def test_windows_empty_list_install_and_removal_keep_bom_and_crlf(self):
        text = '\ufeff# comments\r\n[]\r\n'
        installed = updated_patch(text, PureWindowsPath(r'C:\flower\observer.mjs'))
        self.assertTrue(installed.startswith('\ufeff# comments\r\n'))
        self.assertNotIn('\r\n[]\r\n', installed)
        self.assertEqual(updated_patch(installed), text)

    def test_crlf_removal_and_rollback_preserve_original_bytes(self):
        with tempfile.TemporaryDirectory() as t:
            home = Path(t)
            patch = home / '.dsh/profiles/desktop/cordis.patch.yml'
            patch.parent.mkdir(parents=True)
            original = updated_patch('\ufeff# custom\r\n[]\r\n', home / 'support/dsh/flower-observer.mjs').encode()
            patch.write_bytes(original)
            change = DshPluginChange(home, home / 'support', home / 'backup')
            change.apply()
            self.assertEqual(patch.read_bytes(), '\ufeff# custom\r\n[]\r\n'.encode())
            change.rollback()
            self.assertEqual(patch.read_bytes(), original)

    def test_uninstall_does_not_create_unmanaged_configuration(self):
        with tempfile.TemporaryDirectory() as t:
            home = Path(t)
            change = DshPluginChange(home, home / 'support', home / 'backup')
            change.apply()
            self.assertFalse((home / '.dsh').exists())
            self.assertFalse((home / 'support').exists())
            self.assertEqual(change.written, {})

    def test_apply_rejects_concurrent_plugin_edit_before_changing_patch(self):
        with tempfile.TemporaryDirectory() as t:
            home = Path(t)
            patch = home / '.dsh/profiles/desktop/cordis.patch.yml'
            patch.parent.mkdir(parents=True)
            patch.write_text('[]\n')
            plugin = home / 'support/dsh/flower-observer.mjs'
            plugin.parent.mkdir(parents=True)
            plugin.write_text('original')
            source = home / 'source.mjs'
            source.write_text('replacement')
            change = DshPluginChange(home, home / 'support', home / 'backup', source)
            plugin.write_text('concurrent edit')
            with self.assertRaises(RuntimeError):
                change.apply()
            self.assertEqual(patch.read_text(), '[]\n')
            self.assertEqual(plugin.read_text(), 'concurrent edit')

    def test_rollback_leaves_concurrent_configuration_edit_untouched(self):
        with tempfile.TemporaryDirectory() as t:
            home = Path(t)
            source = home / 'source.mjs'
            source.write_text('plugin')
            change = DshPluginChange(home, home / 'support', home / 'backup', source)
            change.apply()
            change.patch.write_bytes(b'# concurrent edit\r\n[]\r\n')
            change.rollback()
            self.assertEqual(change.patch.read_bytes(), b'# concurrent edit\r\n[]\r\n')

    def test_duplicate_or_reversed_crlf_markers_rejected(self):
        begin, end = BEGIN.replace('\n', '\r\n'), END.replace('\n', '\r\n')
        for text in (begin + begin + end, end + begin, begin):
            with self.assertRaises(ValueError):
                updated_patch(text, Path('/plugin.mjs'))
