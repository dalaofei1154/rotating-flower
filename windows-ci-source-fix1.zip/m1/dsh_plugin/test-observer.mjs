import assert from 'node:assert/strict';
import { test } from 'node:test';
import { mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { setTimeout as delay } from 'node:timers/promises';
import { agentMetadata, observerDirectory, startObserver } from './flower-observer.mjs';
function fixture() {
  const events=[];
  const session={get seq(){return events.length},firstLiveSeq:0,eventAt(i){return events[i]}};
  const agent={id:'synthetic',status:'running',options:{},session};
  const values={modelSelection:{lastUsed:{reasoningEffort:'max',model:'test'}},userQuestions:{active:[]}};
  const projections={snapshot(){return {values}}}; const cache=new WeakMap();
  return {agent,values,add(type,data={}){events.push({type,data})},read(){return agentMetadata(agent,projections,cache)}};
}
test('question blocks until result; async question keeps light',()=>{
  const f=fixture();f.add('turn/start');f.add('tool/call',{name:'ask_user_question',callId:'q'});
  assert.equal(f.read().blocking,true);
  f.add('tool/result',{message:{toolCallId:'q'}});f.values.userQuestions.active=[{state:'continued'}];
  const s=f.read();assert.equal(s.blocking,false);assert.equal(s.questions,1);
  f.values.userQuestions.active=[];assert.equal(f.read().questions,0);
});
test('approval decisions, cancellation and startup midway',()=>{
  const f=fixture();f.add('turn/start');f.add('approval/asked',{id:'a',reason:'SECRET'});
  assert.equal(f.read().approvals,1);
  f.add('approval/decided',{id:'a'});assert.equal(f.read().approvals,0);
  f.add('approval/asked',{id:'b'});f.add('turn/end');f.agent.status='idle';assert.equal(f.read().blocking,false);
});
test('old turns cannot revive; next model is not current model',()=>{
  const f=fixture();f.add('turn/start');f.add('approval/asked',{id:'a'});f.add('turn/end');f.add('turn/start');
  f.values.modelSelection.next={reasoningEffort:'low'};
  assert.equal(f.read().approvals,0);assert.equal(f.read().effort,'max');
  assert.equal(JSON.stringify(f.read()).includes('SECRET'),false);
});

test('Windows metadata uses LOCALAPPDATA and Windows separators on any test host', () => {
  assert.equal(observerDirectory({platform: 'win32', home: 'C:\\Users\\测试用户',
    env: {LOCALAPPDATA: 'D:\\用户数据\\Local'}}), 'D:\\用户数据\\Local\\RotatingFlower\\dsh');
  for (const env of [{}, {LOCALAPPDATA: ''}]) {
    assert.equal(observerDirectory({platform: 'win32', home: 'C:\\Users\\测试用户', env}),
      'C:\\Users\\测试用户\\AppData\\Local\\RotatingFlower\\dsh');
  }
  assert.equal(observerDirectory({platform: 'win32', home: 'C:\\Users\\test',
    env: {LOCALAPPDATA: '\\\\server\\users\\local'}}), '\\\\server\\users\\local\\RotatingFlower\\dsh');
});

test('non-Windows metadata keeps the existing Python support_dir convention', () => {
  for (const platform of ['darwin', 'linux']) {
    assert.equal(observerDirectory({platform, home: '/home/test', env: {LOCALAPPDATA: '/ignored'}}),
      '/home/test/Library/Application Support/RotatingFlower/dsh');
  }
});

test('observer replaces the heartbeat, updates waits, and disconnects on disposal', async () => {
  const root = mkdtempSync(join(tmpdir(), 'flower-observer-'));
  const file = join(root, 'status.json');
  const f = fixture();
  let dispose;
  try {
    writeFileSync(file, '{"old":true}');
    f.add('turn/start');
    startObserver({agents: {list: () => [f.agent]},
      sessionProjections: {snapshot: () => ({values: f.values})},
      effect: callback => { dispose = callback(); }}, root);
    const initial = JSON.parse(readFileSync(file, 'utf8'));
    assert.equal(initial.schema, 1);
    assert.equal(initial.connected, true);
    assert.equal(initial.pid, process.pid);
    assert.equal(initial.tasks[0].running, true);
    f.add('tool/call', {name: 'ask_user_question', callId: 'q', arguments: 'SECRET QUESTION'});
    await delay(650);
    const waiting = JSON.parse(readFileSync(file, 'utf8'));
    assert.equal(waiting.instance, initial.instance);
    assert.ok(waiting.updated_at > initial.updated_at);
    assert.equal(waiting.tasks[0].blocking, true);
    assert.equal(waiting.tasks[0].questions, 1);
    assert.equal(JSON.stringify(waiting).includes('SECRET QUESTION'), false);
    dispose(); dispose = undefined;
    const stopped = JSON.parse(readFileSync(file, 'utf8'));
    assert.equal(stopped.connected, false);
    assert.deepEqual(stopped.tasks, []);
  } finally {
    dispose?.();
    rmSync(root, {recursive: true, force: true});
  }
});

test('incompatible task metadata produces a disconnected error heartbeat', () => {
  const root = mkdtempSync(join(tmpdir(), 'flower-observer-'));
  let dispose;
  try {
    startObserver({agents: {list() { throw new Error('SECRET APPLICATION DATA'); }},
      sessionProjections: {}, effect: callback => { dispose = callback(); }}, root);
    const value = JSON.parse(readFileSync(join(root, 'status.json'), 'utf8'));
    assert.equal(value.connected, false);
    assert.equal(value.error, 'unsupported_task_metadata');
    assert.deepEqual(value.tasks, []);
    assert.equal(JSON.stringify(value).includes('SECRET APPLICATION DATA'), false);
  } finally {
    dispose?.();
    rmSync(root, {recursive: true, force: true});
  }
});
