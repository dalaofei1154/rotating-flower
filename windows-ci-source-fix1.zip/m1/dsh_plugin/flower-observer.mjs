// Local metadata observer for DeepSeek Harness 0.2.1-rc.5.
// No network, credentials, message bodies, prompts or approval decisions.
import { mkdirSync, writeFileSync, renameSync } from 'node:fs';
import { homedir } from 'node:os';
import { join, win32, posix } from 'node:path';
import { randomUUID } from 'node:crypto';

// Match integrated/platform_support.py, independently of the host running tests.
export function observerDirectory({platform = process.platform, home = homedir(), env = process.env} = {}) {
  if (platform === 'win32') {
    return win32.join(env.LOCALAPPDATA || win32.join(home, 'AppData', 'Local'), 'RotatingFlower', 'dsh');
  }
  return posix.join(home, 'Library', 'Application Support', 'RotatingFlower', 'dsh');
}

export function foldEvent(state, event) {
  const d = event?.data;
  if (!d) return;
  if (event.type === 'turn/start' || event.type === 'turn/end') {
    state.questions.clear(); state.approvals.clear();
  } else if (event.type === 'tool/call' && d.name === 'ask_user_question') {
    state.questions.add(d.callId);
  } else if (event.type === 'tool/result') {
    state.questions.delete(d.message?.toolCallId);
  } else if (event.type === 'approval/asked') {
    state.approvals.add(d.id);
  } else if (event.type === 'approval/decided') {
    state.approvals.delete(d.id);
  }
}

export function agentMetadata(agent, projections, cursors) {
  const session = agent.session;
  let state = cursors.get(session);
  if (!state || state.seq > session.seq) {
    // Only the current turn can own foreground waits. Bound startup work.
    let start = session.seq;
    const floor = Math.max(session.firstLiveSeq ?? 0, session.seq - 10000);
    while (start > floor) {
      const event = session.eventAt(--start);
      if (event?.type === 'turn/start' || event?.type === 'turn/end') break;
    }
    state = {seq: start, questions: new Set(), approvals: new Set()};
    cursors.set(session, state);
  }
  // Process incrementally; only event type and opaque call IDs are retained.
  while (state.seq < session.seq) foldEvent(state, session.eventAt(state.seq++));
  const values = projections.snapshot(session, ['modelSelection', 'userQuestions']).values;
  const selection = values.modelSelection?.lastUsed ?? agent.options ?? {};
  const active = values.userQuestions?.active ?? [];
  const running = agent.status === 'running';
  const blockingQuestions = running ? state.questions.size : 0;
  const approvals = running ? state.approvals.size : 0;
  return {
    id: String(agent.id), running,
    effort: typeof selection.reasoningEffort === 'string' ? selection.reasoningEffort : null,
    model: typeof selection.model === 'string' ? selection.model : null,
    blocking: blockingQuestions + approvals > 0,
    questions: Math.max(blockingQuestions, active.length), approvals,
  };
}

export function startObserver(scope, root = observerDirectory()) {
  const file = join(root, 'status.json');
  const instance = randomUUID();
  const temporary = join(root, `status.${instance}.tmp`);
  const cursors = new WeakMap();
  let disposed = false;
  const write = (connected = true) => {
    if (disposed && connected) return;
    try {
      let tasks = [], error = null;
      try {
        if (connected) tasks = scope.agents.list().map(a => agentMetadata(a, scope.sessionProjections, cursors));
      } catch {
        error = 'unsupported_task_metadata';
      }
      mkdirSync(root, {recursive: true, mode: 0o700});
      writeFileSync(temporary, JSON.stringify({schema: 1, instance, pid: process.pid,
        updated_at: Date.now() / 1000, connected: connected && !error, error, tasks}), {mode: 0o600});
      renameSync(temporary, file);
    } catch { /* Observability must never disrupt DSH or change its decisions. */ }
  };
  scope.effect(() => {
    write();
    const timer = setInterval(write, 500);
    timer.unref?.();
    return () => { disposed = true; clearInterval(timer); write(false); };
  }, 'rotating-flower metadata heartbeat');
}

export default function flowerObserver(ctx) {
  ctx.inject(['agents', 'sessionProjections'], (scope) => startObserver(scope));
}
