"""Install our metadata-only DSH plugin using the supported profile patch layer."""
from pathlib import Path, PurePath
import json
import os
import re

BEGIN = '# BEGIN ROTATING-FLOWER DSH OBSERVER\n'
END = '# END ROTATING-FLOWER DSH OBSERVER\n'

def plugin_file_uri(plugin):
    """Use an ESM file URL, including on loaders that do not normalize C:\\ paths."""
    path = plugin if isinstance(plugin, PurePath) else Path(plugin)
    if isinstance(path, Path):
        path = path.absolute()
    return path.as_uri()

def without_block(text):
    if text.startswith('\ufeff'):
        return '\ufeff' + without_block(text[1:])
    starts = list(re.finditer(r'(?m)^' + re.escape(BEGIN.rstrip('\n')) + r'(?:\r?\n|$)', text))
    ends = list(re.finditer(r'(?m)^' + re.escape(END.rstrip('\n')) + r'(?:\r?\n|$)', text))
    if not starts and not ends:
        if BEGIN.rstrip('\n') in text or END.rstrip('\n') in text:
            raise ValueError('DSH 小花配置标记不完整，未修改原配置。')
        if 'rotating-flower-observer' in text:
            raise ValueError('DSH 中已有非标准小花插件配置，已保留；请先核对配置。')
        return text
    if len(starts) != 1 or len(ends) != 1:
        raise ValueError('DSH 小花配置标记不完整，未修改原配置。')
    start, end = starts[0], ends[0]
    if end.start() < start.start():
        raise ValueError('DSH 小花配置标记顺序错误。')
    return text[:start.start()] + text[end.end():]

def updated_patch(text, plugin=None):
    bom = '\ufeff' if text.startswith('\ufeff') else ''
    if bom:
        text = text[1:]
    newline = '\r\n' if '\r\n' in text else '\n'
    text = without_block(text)
    if plugin is None:
        if not any(line.strip() and not line.lstrip().startswith('#') for line in text.splitlines()):
            return bom + text + ('' if not text or text.endswith('\n') else newline) + '[]' + newline
        return bom + text
    # An empty YAML list cannot be followed by block-sequence entries.
    content = [line for line in text.splitlines() if line.strip() and not line.lstrip().startswith('#')]
    if content and len(content) == 1 and content[0].strip() == '[]':
        text = ''.join(line for line in text.splitlines(keepends=True) if line.strip() != '[]')
    block = BEGIN + ('- insert:\n    - id: rotating-flower-observer\n      name: ' +
                     json.dumps(plugin_file_uri(plugin), ensure_ascii=False) + '\n') + END
    return bom + text + ('' if not text or text.endswith('\n') else newline) + block.replace('\n', newline)

def atomic_write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + '.flower-tmp')
    created = False
    try:
        fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        created = True
        with os.fdopen(fd, 'wb') as f:
            f.write(data)
        temp.replace(path)
    finally:
        if created:
            temp.unlink(missing_ok=True)

class DshPluginChange:
    def __init__(self, home, support, backup, source=None):
        self.patch = Path(home) / '.dsh/profiles/desktop/cordis.patch.yml'
        self.plugin = Path(support) / 'dsh/flower-observer.mjs'
        self.original = {p: p.read_bytes() if p.exists() else None for p in (self.patch, self.plugin)}
        self.backup = Path(backup)
        self.source = source
        self.written = {}

    def apply(self):
        old = self.original[self.patch]
        text = (old or b'').decode('utf-8')
        if not self.source and BEGIN.rstrip('\n') not in text and END.rstrip('\n') not in text:
            return
        updated = updated_patch(text, self.plugin if self.source else None).encode()
        if not self.source and updated == (old or b''):
            return
        for path, original in self.original.items():
            if (path.read_bytes() if path.exists() else None) != original:
                raise RuntimeError('DSH 配置或插件在安装过程中改变，已停止以避免覆盖。')
        for path, data in self.original.items():
            if data is not None:
                self.backup.mkdir(parents=True, exist_ok=True)
                (self.backup / ('dsh-' + path.name)).write_bytes(data)
        if self.source:
            data = Path(self.source).read_bytes()
            atomic_write(self.plugin, data)
            self.written[self.plugin] = data
        if (self.patch.read_bytes() if self.patch.exists() else None) != old:
            raise RuntimeError('DSH 配置在安装过程中改变，已停止以避免覆盖。')
        atomic_write(self.patch, updated)
        self.written[self.patch] = updated
        # Keep the inactive plugin as rollback material after removing its entry.

    def rollback(self):
        for path, written in reversed(list(self.written.items())):
            if not path.exists() or path.read_bytes() != written:
                continue  # Never overwrite a concurrent user edit.
            original = self.original[path]
            if original is None:
                path.unlink()
            else:
                atomic_write(path, original)
