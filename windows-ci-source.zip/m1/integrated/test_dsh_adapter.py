import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from dsh_adapter import DshAdapter, speed_for_effort
from integrated_bridge import combine_sources
from source_config import enabled_sources, selection_for
from platform_support import open_read_shared

class DshTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / 'status.json'
        self.adapter = DshAdapter(self.path)
    def state(self, tasks=(), **changes):
        d = dict(schema=1, instance='test', pid=os.getpid(), updated_at=100, connected=True, error=None, tasks=list(tasks) if tasks is not None else None)
        d.update(changes)
        self.path.write_text(json.dumps(d))
        return self.adapter.poll(100)
    def task(self, **kw):
        t=dict(id='task-a', running=True, blocking=False, effort='max', questions=0, approvals=0)
        t.update(kw)
        return t
    def test_effort_mapping(self):
        self.assertEqual([speed_for_effort(e) for e in ('off','low','high','max',None,'new')], ['LOW','MEDIUM','HIGH','ULTRA','LOW','HIGH'])
    def test_running(self):
        s=self.state([self.task()]);self.assertEqual(s['motor'],'RUN ULTRA');self.assertFalse(s['light'])
    def test_heartbeat_can_be_replaced_while_adapter_reads(self):
        self.state([self.task()])
        newer = json.loads(self.path.read_text())
        newer['tasks'] = []
        replacement = self.path.with_suffix('.tmp')
        replacement.write_text(json.dumps(newer))

        def replace_after_open(path):
            stream = open_read_shared(path)
            try:
                replacement.replace(path)
            except BaseException:
                stream.close()
                raise
            return stream

        with patch('dsh_adapter.open_read_shared', side_effect=replace_after_open):
            snapshot = self.adapter.poll(100)
        self.assertTrue(snapshot['healthy'])
        self.assertEqual(snapshot['motor'], 'RUN ULTRA')
        self.assertEqual(self.adapter.poll(100)['motor'], 'STOP')
    def test_blocking_question(self):
        s=self.state([self.task(blocking=True,questions=1)]);self.assertEqual(s['motor'],'STOP');self.assertTrue(s['light'])
    def test_approval(self):
        s=self.state([self.task(blocking=True,approvals=1)]);self.assertEqual(s['motor'],'STOP');self.assertTrue(s['light'])
    def test_async_question_still_works(self):
        s=self.state([self.task(questions=1)]);self.assertEqual(s['motor'],'RUN ULTRA');self.assertTrue(s['light'])
    def test_idle_pending_question(self):
        s=self.state([self.task(running=False,questions=1)]);self.assertEqual(s['motor'],'STOP');self.assertTrue(s['light'])
    def test_other_task_continues(self):
        s=self.state([self.task(blocking=True,questions=1),self.task(id='task-b',effort='low')]);self.assertEqual(s['motor'],'RUN MEDIUM');self.assertTrue(s['light'])
    def test_terminal(self):
        s=self.state([self.task(running=False)]);self.assertEqual(s['motor'],'STOP');self.assertFalse(s['light'])
    def test_stale_and_future(self):
        for t in (96,103):
            s=self.state([self.task()],updated_at=t);self.assertFalse(s['healthy']);self.assertEqual(s['motor'],'STOP')
    def test_exit(self):
        s=self.state([self.task()],connected=False);self.assertFalse(s['healthy'])
        with patch('dsh_adapter.process_alive', return_value=False):
            self.assertFalse(self.state([self.task()])['healthy'])
    def test_missing(self):
        self.assertEqual(self.adapter.poll(100)['readiness'],'not_initialized')
    def test_bad_metadata(self):
        for change in ({'schema':2},{'tasks':None},{'pid':True},{'updated_at':float('nan')},{'error':'incompatible'}):
            self.assertEqual(self.state(**change)['readiness'],'error')
        for change in ({'questions':-1},{'approvals':True},{'running':'yes'},{'effort':{}},{'blocking':0}):
            self.assertEqual(self.state([self.task(**change)])['readiness'],'error')
    def test_no_revival_when_disconnected(self):
        bad=self.state([self.task(questions=1)],updated_at=90)
        other=dict(healthy=True,motor='RUN HIGH',light=False)
        self.assertEqual(combine_sources({'dsh':bad,'codex':other}),('RUN HIGH',False))
    def test_selections(self):
        for names in (('dsh',),('codex','dsh'),('workbuddy','dsh'),('codex','workbuddy','dsh')):
            self.assertEqual(enabled_sources(selection_for(names)),names)
        self.assertEqual(enabled_sources('both'),('codex','workbuddy'))
