#!/usr/bin/env python3
"""Build the Windows software-preview source ZIP; no runtime is bundled."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import tempfile
import zipfile

from windows_setup import APP_FILES, BRIDGE_FILES, SOURCES, VERSION

NAME = 'RotatingFlower-Windows-v' + VERSION
SCRIPTS = ('install.cmd', 'start.cmd', 'stop.cmd', 'check.cmd', 'diagnose.cmd', 'uninstall.cmd',
           'launch.cmd', 'find-python.ps1')
GUIDE = """旋转花 · Windows 软件预览版

本包是需要 Python 的软件预览包，不是免依赖 EXE。DSH 0.2.2-rc.3 已有 Win10
现场 file URI 修复后的成功记录；本版收录该修复方向，新包安装仍待复验。
需要 Windows 桌面环境、Python 3.11 或更新版本；安装时联网从 PyPI 下载
经过固定版本与 SHA256 校验的 pyserial 3.5，并建立独立 Python 虚拟环境。
Python 下载：https://www.python.org/downloads/windows/
虚拟环境仍依赖安装时的基础 Python，请勿在使用期间卸载该 Python。

1. 将整个 ZIP 解压到本地文件夹。不要直接在压缩文件内运行。
2. 双击 install.cmd。首次默认启用 Codex + WorkBuddy，并使用软件检查模式：
   读取应用状态、写入日志，但不打开 USB、不转动、不亮灯。
3. 双击 check.cmd 查看后台和各应用状态；diagnose.cmd 做一次只读诊断。
   未安装/未初始化的应用可能显示等待；接口不兼容会显示错误，不冒充已连接。
4. start.cmd 启动已安装后台；stop.cmd 暂停（直到再次 start，期间登录也保持停止），
   uninstall.cmd 停止并移除登录自启。

命令行选项（在解压文件夹打开终端）：
  py -3 -X utf8 app/windows_setup.py install --source workbuddy
  py -3 -X utf8 app/windows_setup.py install --source dsh --dry-run
  py -3 -X utf8 app/windows_setup.py install --source workbuddy,dsh --dry-run
  py -3 -X utf8 app/windows_setup.py install --source all --dry-run
  py -3 -X utf8 app/windows_setup.py install --source qodercn --dry-run
  py -3 -X utf8 app/windows_setup.py install --source codex,workbuddy,dsh,qodercn --dry-run
  py -3 -X utf8 app/windows_setup.py install --source codex --sessions-root "D:\\my codex\\sessions"
  py -3 -X utf8 app/windows_setup.py install --codex-endpoint "Windows 上已确认的实际 IPC 端点"
  py -3 -X utf8 app/windows_setup.py install --enable-hardware --port COM10
  py -3 -X utf8 app/windows_setup.py install --enable-hardware --port auto
  py -3 -X utf8 app/windows_setup.py install --dry-run

enable-hardware 明确开启 USB 控制；请准备好硬件后再使用。
重新安装会保留已有来源、路径、端口和软件检查/硬件模式，只有显式选项会覆盖。
首次默认 both；只有一个应用时请指定 --source codex 或 --source workbuddy。
Qoder CN 来自 Y1X1n 的 PR #8（b06b3da），本整合候选版尚未完成 Windows 实机验证。
all 保持 Codex + WorkBuddy + DSH；加入 Qoder 请显式选择 qodercn 或上面的四来源组合。
Qoder 默认读取 ~/.qoder-cn，可用 --qoder-root 与 --qoder-app-data 指定路径；重装保留配置。
Qoder 问答等待支持提醒灯，权限授权等待目前不支持；无更新的会话超过十分钟会过期。
Windows 版应用内部状态格式、Codex IPC 端点及协议仍需在目标机器核验。
DSH 首轮仅支持 Windows 原生官方桌面版，默认使用 ~/.dsh/profiles/desktop。
启用 DSH 会安装受管观察插件；安装后重启 DSH 并创建新任务做软件检查。
切换到不含 DSH 的来源或卸载会移除受管插件配置，保留其他用户配置。
WSL 和自定义 profile 不属于本轮；不会修改应用数据库，也不烧录固件。

安装目录：%LOCALAPPDATA%\\RotatingFlower
日志：安装目录\\logs\\bridge.log（启动失败另见 runner-error.log）
配置：安装目录\\config.json；软件状态：status.json
当前用户登录自启：HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run 的 RotatingFlower 项。
不需要管理员权限。卸载保留运行文件、备份和日志，以便排查或恢复。
安装、切换模式和启动请在用户自行打开的终端或文件资源管理器中执行；
AI 工具启动的后台可能受任务清理影响。现场修复成功不等于本 ZIP 已完成 Windows 安装复验。
软件来源和许可见 LICENSE；包内无账号、聊天记录、缓存或本地用户配置。
"""


def build(output: Path):
    source = Path(__file__).resolve().parent
    files = {f'app/integrated/{name}': source / 'integrated' / name for name in BRIDGE_FILES}
    files.update({name: source / 'windows' / name for name in SCRIPTS})
    files.update({f'app/{name}': source / name for name in APP_FILES})
    files['LICENSE'] = source.parent / 'LICENSE'
    missing = [str(path) for path in files.values() if not path.is_file()]
    if missing:
        raise ValueError('Missing package files: ' + ', '.join(missing))
    output.mkdir(parents=True, exist_ok=True)
    contents = {name: path.read_bytes() for name, path in files.items()}
    # CRLF .cmd files work in cmd.exe regardless of the authoring host.
    for name in SCRIPTS:
        contents[name] = contents[name].replace(b'\r\n', b'\n').replace(b'\n', b'\r\n')
    contents['先看这里.txt'] = GUIDE.encode('utf-8-sig')
    checksums = {name: hashlib.sha256(data).hexdigest() for name, data in sorted(contents.items())}
    manifest = {'version': VERSION, 'runtime_bundled': False, 'requires_python': '>=3.11',
                'installation_network_downloads': True, 'hardware_verified': False,
                'windows_runtime_verified': False, 'default_dry_run': True,
                'supported_sources': ['codex', 'workbuddy', 'dsh', 'qodercn'], 'source_choices': list(SOURCES),
                'dsh_windows_integrated': True, 'dsh_profile': 'desktop',
                'dsh_windows_runtime_verified': False,
                'qodercn_windows_runtime_verified': False,
                'qodercn_upstream_commit': 'b06b3da016caeb04b00214f3c2745207aa8c0aea',
                'files': checksums}
    contents['manifest.json'] = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    target = output / (NAME + '.zip')
    with tempfile.NamedTemporaryFile(prefix='.windows-package-', suffix='.zip', dir=output, delete=False) as tmp:
        temporary = Path(tmp.name)
    try:
        with zipfile.ZipFile(temporary, 'w', zipfile.ZIP_DEFLATED) as archive:
            for name, data in sorted(contents.items()):
                info = zipfile.ZipInfo(NAME + '/' + name, (2026, 11, 10, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                info.external_attr = 0o100644 << 16
                archive.writestr(info, data)
        temporary.replace(target)
    finally:
        temporary.unlink(missing_ok=True)
    digest = hashlib.sha256(target.read_bytes()).hexdigest()
    target.with_suffix('.zip.sha256').write_text(f'{digest}  {target.name}\n', encoding='ascii')
    return target


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, type=Path)
    print(build(parser.parse_args().output))
