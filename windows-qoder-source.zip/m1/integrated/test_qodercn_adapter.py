import json
import os
from pathlib import Path
import sqlite3
import sys
import tempfile
import time
import unittest

sys.path.insert(0, str(Path(__file__).parent))
from qodercn_adapter import AppLogEffort, ModelEffortCatalog, QoderCnSource, speed_for_effort
from source_config import CHOICES, NAMES, enabled_sources, selection_for


def assistant(*blocks, stop=None, message_id='as-1', model='magpie/group/safely-deepseek'):
    content = []
    for block in blocks:
        if block == 'thinking':
            content.append({'type': 'thinking', 'thinking': 'considering'})
        elif block == 'text':
            content.append({'type': 'text', 'text': 'done'})
        else:
            content.append({'type': 'tool_use', 'id': 'call-' + block, 'name': block, 'input': {}})
    return json.dumps({'type': 'assistant', 'isSidechain': False,
                       'message': {'id': message_id, 'role': 'assistant', 'model': model,
                                   'stop_reason': stop, 'content': content}})


def user_tool_result(tool_use_id='call-Bash'):
    return json.dumps({'type': 'user', 'isSidechain': False,
                       'message': {'role': 'user', 'content': [
                           {'type': 'tool_result', 'tool_use_id': tool_use_id, 'content': 'ok'}]}})


def user_prompt(text='do the task'):
    return json.dumps({'type': 'user', 'isSidechain': False,
                       'message': {'role': 'user', 'content': [{'type': 'text', 'text': text}]}})


def runtime_config(model='magpie/group/safely-deepseek', effort=None):
    return json.dumps({'type': 'runtime-config', 'model': model, 'reasoningEffort': effort})


def policy_line(session, effort):
    return ('2026-11-13T00:00:00.000Z [INFO] [main] [ChatSession] '
            'ChatSession model policy returning to SDK ' + json.dumps(
                {'sessionId': session, 'turnId': 'turn-1', 'isActivePolicy': True,
                 'frozenReasoningEffort': effort, 'hasReasoningEffort': True,
                 'reasoningEffort': effort}))


class QoderCnSourceTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='qoder source ')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name) / '.qoder-cn'
        (self.root / 'projects').mkdir(parents=True)
        self.app_data = Path(self.temp.name) / 'appdata'
        self.app_data.mkdir()
        self.now = time.time()

    def preferences(self, rows):
        connection = sqlite3.connect(self.app_data / 'main.sqlite')
        try:
            connection.execute('CREATE TABLE chat_model_preferences '
                               '(model_key TEXT PRIMARY KEY, reasoning_effort TEXT)')
            connection.executemany('INSERT INTO chat_model_preferences VALUES (?, ?)', rows)
            connection.commit()
        finally:
            connection.close()

    def write(self, lines, project='workspace', session='s1'):
        directory = self.root / 'projects' / project
        directory.mkdir(parents=True, exist_ok=True)
        path = directory / (session + '.jsonl')
        path.write_text('\n'.join(lines) + '\n', encoding='utf-8')
        return path

    def append(self, path, lines):
        with path.open('a', encoding='utf-8') as file:
            file.write('\n'.join(lines) + '\n')

    def write_log(self, lines, run='run-1'):
        directory = self.app_data / 'logs' / run
        directory.mkdir(parents=True, exist_ok=True)
        path = directory / 'main.log'
        path.write_text('\n'.join(lines) + '\n', encoding='utf-8')
        return path

    def poll(self, source=None, now=None):
        source = source or QoderCnSource(self.root, self.app_data)
        return source.poll(self.now if now is None else now)

    # --- readiness -------------------------------------------------------

    def test_a_missing_qoder_root_waits_for_first_use(self):
        result = QoderCnSource(Path(self.temp.name) / 'missing', self.app_data).poll(self.now)
        self.assertFalse(result['healthy'])
        self.assertEqual(result['readiness'], 'not_initialized')
        self.assertEqual(result['motor'], 'STOP')

    def test_a_root_without_task_records_is_not_initialized(self):
        root = Path(self.temp.name) / 'empty-root'
        root.mkdir()
        result = QoderCnSource(root, self.app_data).poll(self.now)
        self.assertEqual(result['readiness'], 'not_initialized')
        self.assertFalse(result['healthy'])

    def test_a_task_directory_file_is_an_error(self):
        (self.root / 'projects').rmdir()
        (self.root / 'projects').write_text('not a directory')
        result = self.poll()
        self.assertEqual(result['readiness'], 'error')

    def test_ready_when_the_projects_directory_is_readable(self):
        self.write([user_prompt(), assistant('text', stop='end_turn')])
        result = self.poll()
        self.assertTrue(result['healthy'])
        self.assertEqual(result['readiness'], 'ready')

    # --- work and attention ----------------------------------------------

    def test_a_pending_tool_marks_the_task_working(self):
        self.write([user_prompt(), assistant('thinking'),
                    assistant('Bash', stop='tool_use')])
        result = self.poll()
        self.assertEqual(result['motor'], 'RUN MEDIUM')
        self.assertFalse(result['light'])
        self.assertEqual(result['working_threads'], ['s1'])
        self.assertEqual(result['waiting_threads'], [])

    def test_a_pending_question_pauses_and_lights(self):
        self.write([user_prompt(),
                    assistant('AskUserQuestion', stop='tool_use')])
        result = self.poll()
        self.assertEqual(result['motor'], 'STOP')
        self.assertTrue(result['light'])
        self.assertEqual(result['waiting_threads'], ['s1'])
        self.assertEqual(result['pending_questions'], 1)

    def test_an_answered_question_resumes_work(self):
        path = self.write([user_prompt(), assistant('AskUserQuestion', stop='tool_use')])
        self.poll()
        self.append(path, [user_tool_result('call-AskUserQuestion')])
        result = self.poll()
        self.assertEqual(result['motor'], 'RUN MEDIUM')
        self.assertFalse(result['light'])
        self.assertEqual(result['working_threads'], ['s1'])

    def test_an_unrelated_tool_result_keeps_the_question_pending(self):
        path = self.write([user_prompt(),
                           assistant('AskUserQuestion', 'Bash', stop='tool_use')])
        self.assertEqual(self.poll()['waiting_threads'], ['s1'])
        self.append(path, [user_tool_result('call-Bash')])
        result = self.poll()
        self.assertEqual(result['waiting_threads'], ['s1'])
        self.assertTrue(result['light'])
        self.assertEqual(result['motor'], 'STOP')

    def test_the_matching_result_clears_the_pending_question(self):
        path = self.write([user_prompt(),
                           assistant('AskUserQuestion', 'Bash', stop='tool_use')])
        self.poll()
        self.append(path, [user_tool_result('call-Bash'),
                           user_tool_result('call-AskUserQuestion')])
        self.assertEqual(self.poll()['working_threads'], ['s1'])

    def test_a_parallel_response_with_a_question_still_waits(self):
        self.write([user_prompt(),
                    assistant('AskUserQuestion', stop=None),
                    assistant('Bash', stop='tool_use')])
        self.assertEqual(self.poll()['waiting_threads'], ['s1'])

    def test_a_finished_turn_stops_without_a_light(self):
        self.write([user_prompt(), assistant('thinking'),
                    assistant('text', stop='end_turn')])
        result = self.poll()
        self.assertEqual(result['motor'], 'STOP')
        self.assertFalse(result['light'])
        self.assertEqual(result['working_threads'], [])

    def test_an_interrupted_turn_is_idle(self):
        self.write([user_prompt(), assistant('Bash', stop='tool_use'),
                    user_prompt('[Request interrupted by user]')])
        self.assertEqual(self.poll()['motor'], 'STOP')

    def test_parallel_sessions_take_the_fastest_active_speed(self):
        self.write([runtime_config(effort='xhigh'), user_prompt(),
                    assistant('Bash', stop='tool_use')], session='fast')
        self.write([user_prompt(), assistant('AskUserQuestion', stop='tool_use')],
                   session='waiting')
        result = self.poll()
        self.assertEqual(result['motor'], 'RUN XHIGH')
        self.assertTrue(result['light'])
        self.assertEqual(result['working_threads'], ['fast'])
        self.assertEqual(result['waiting_threads'], ['waiting'])

    # --- speed mapping ---------------------------------------------------

    def test_effort_tiers_map_to_motor_speeds(self):
        for effort, speed in [('minimal', 'LOW'), ('low', 'LOW'), ('medium', 'MEDIUM'),
                              ('high', 'HIGH'), ('xhigh', 'XHIGH'), ('max', 'ULTRA')]:
            self.assertEqual(speed_for_effort(effort), speed, effort)
        self.assertIsNone(speed_for_effort(None))
        self.assertIsNone(speed_for_effort('turbo'))

    def test_runtime_effort_wins_over_the_model_catalog(self):
        self.preferences([('byok:magpie/group%2Fsafely-deepseek', 'max')])
        self.write([runtime_config(effort='low'), user_prompt(),
                    assistant('Bash', stop='tool_use')])
        self.assertEqual(self.poll()['motor'], 'RUN LOW')

    def test_the_model_catalog_supplies_a_missing_effort(self):
        self.preferences([('byok:magpie/group%2Fsafely-deepseek', 'max'),
                          ('fast', 'low')])
        self.write([user_prompt(), assistant('Bash', stop='tool_use')])
        self.assertEqual(self.poll()['motor'], 'RUN ULTRA')

    def test_an_unconfigured_model_stays_neutral(self):
        self.write([runtime_config(model='qmodel_latest'), user_prompt(),
                    assistant('Bash', stop='tool_use')])
        self.assertEqual(self.poll()['motor'], 'RUN MEDIUM')

    def test_the_app_log_supplies_the_real_per_turn_effort(self):
        for effort, expected in (('low', 'RUN LOW'), ('high', 'RUN HIGH'), ('max', 'RUN ULTRA')):
            with self.subTest(effort=effort):
                self.write([user_prompt(), assistant('Bash', stop='tool_use')])
                self.write_log([policy_line('s1', effort)])
                self.assertEqual(self.poll()['motor'], expected)

    def test_appended_policy_lines_update_the_effort(self):
        self.write([user_prompt(), assistant('Bash', stop='tool_use')])
        log = self.write_log([policy_line('s1', 'low')])
        source = QoderCnSource(self.root, self.app_data)
        self.assertEqual(source.poll(self.now)['motor'], 'RUN LOW')
        self.append(log, [policy_line('s1', 'max')])
        self.assertEqual(source.poll(time.time() + 1)['motor'], 'RUN ULTRA')

    def test_the_app_log_outranks_the_static_model_default(self):
        self.preferences([('byok:magpie/group%2Fsafely-deepseek', 'max')])
        self.write([user_prompt(), assistant('Bash', stop='tool_use')])
        self.write_log([policy_line('s1', 'low')])
        self.assertEqual(self.poll()['motor'], 'RUN LOW')

    def test_a_missing_app_log_still_uses_the_model_default(self):
        self.preferences([('byok:magpie/group%2Fsafely-deepseek', 'max')])
        self.write([user_prompt(), assistant('Bash', stop='tool_use')])
        self.assertEqual(self.poll()['motor'], 'RUN ULTRA')

    def test_an_effort_seen_before_the_transcript_is_kept(self):
        # The app log can be read before the session transcript appears.
        self.write_log([policy_line('s1', 'max')])
        source = QoderCnSource(self.root, self.app_data)
        self.assertTrue(source.poll(self.now)['healthy'])
        self.write([user_prompt(), assistant('Bash', stop='tool_use')])
        self.assertEqual(source.poll(time.time() + 1)['motor'], 'RUN ULTRA')

    def test_an_unmatched_effort_is_dropped_after_retention(self):
        self.write_log([policy_line('s1', 'max')])
        source = QoderCnSource(self.root, self.app_data)
        source.poll(self.now)
        self.assertIn('s1', source.effort_log.efforts)
        source.poll(self.now + AppLogEffort.RETENTION + 1)
        self.assertEqual(source.effort_log.efforts, {})

    def test_policy_lines_from_other_sessions_do_not_leak(self):
        self.write([user_prompt(), assistant('Bash', stop='tool_use')])
        self.write_log([policy_line('other-session', 'low')])
        self.assertEqual(self.poll()['motor'], 'RUN MEDIUM')

    def test_the_app_log_is_read_from_the_newest_run_only(self):
        old = self.app_data / 'logs' / 'old-run' / 'main.log'
        old.parent.mkdir(parents=True)
        old.write_text(policy_line('s1', 'low') + '\n', encoding='utf-8')
        os.utime(old, (self.now - 60, self.now - 60))
        self.write([user_prompt(), assistant('Bash', stop='tool_use')])
        self.write_log([policy_line('s1', 'max')], run='new-run')
        self.assertEqual(self.poll()['motor'], 'RUN ULTRA')

    def test_non_policy_log_lines_are_ignored(self):
        self.write([user_prompt(), assistant('Bash', stop='tool_use')])
        self.write_log(['2026-11-13T00:00:00Z [INFO] unrelated line',
                        '{"sessionId":"s1","frozenReasoningEffort":"low"}'])
        self.assertEqual(self.poll()['motor'], 'RUN MEDIUM')

    def test_a_rotated_log_is_still_read(self):
        self.write([user_prompt(), assistant('Bash', stop='tool_use')])
        directory = self.app_data / 'logs' / 'run-3'
        directory.mkdir(parents=True)
        old = directory / 'main.1.log'
        old.write_text(policy_line('s1', 'low') + '\n', encoding='utf-8')
        os.utime(old, (self.now - 60, self.now - 60))
        (directory / 'main.log').write_text(policy_line('s1', 'max') + '\n', encoding='utf-8')
        self.assertEqual(self.poll()['motor'], 'RUN ULTRA')

    def test_no_appdata_paths_are_ever_none(self):
        import qodercn_adapter
        from unittest.mock import patch
        with patch.dict(os.environ, {'APPDATA': ''}):
            for path in qodercn_adapter.app_data_candidates():
                self.assertIsInstance(path, Path)

    def test_a_source_without_app_data_still_works(self):
        from unittest.mock import patch
        self.write([user_prompt(), assistant('Bash', stop='tool_use')])
        with patch.dict(os.environ, {'APPDATA': ''}):
            result = QoderCnSource(self.root, None).poll(self.now)
        self.assertTrue(result['healthy'])
        self.assertEqual(result['motor'], 'RUN MEDIUM')

    def test_a_missing_catalog_fails_quiet(self):
        catalog = ModelEffortCatalog(self.app_data / 'missing')
        self.assertIsNone(catalog.effort('magpie/group/safely-deepseek'))

    # --- file lifecycle --------------------------------------------------

    def test_a_stale_transcript_is_not_working(self):
        path = self.write([user_prompt(), assistant('Bash', stop='tool_use')])
        old = self.now - 3600
        os.utime(path, (old, old))
        self.assertEqual(self.poll()['motor'], 'STOP')

    def test_appended_records_are_read_incrementally(self):
        path = self.write([user_prompt(), assistant('text', stop='end_turn')])
        source = QoderCnSource(self.root, self.app_data)
        self.assertEqual(source.poll(self.now)['motor'], 'STOP')
        self.append(path, [user_prompt('again'), assistant('Bash', stop='tool_use')])
        result = source.poll(time.time() + 1)
        self.assertEqual(result['motor'], 'RUN MEDIUM')
        self.assertEqual(result['working_threads'], ['s1'])

    def test_a_rewritten_transcript_rebuilds_state(self):
        path = self.write([user_prompt(), assistant('Bash', stop='tool_use')])
        source = QoderCnSource(self.root, self.app_data)
        self.assertEqual(source.poll(self.now)['motor'], 'RUN MEDIUM')
        path.write_text('\n'.join([user_prompt(), assistant('text', stop='end_turn')]) + '\n',
                        encoding='utf-8')
        self.assertEqual(source.poll(time.time() + 1)['motor'], 'STOP')

    def test_malformed_and_bookkeeping_records_are_ignored(self):
        self.write(['{"type":"system","subtype":"compact_boundary"}', 'not json',
                    json.dumps({'type': 'active-leaf', 'leafUuid': 'x'}),
                    json.dumps({'type': 'file-history-snapshot'}),
                    user_prompt(), assistant('Bash', stop='tool_use')])
        result = self.poll()
        self.assertEqual(result['motor'], 'RUN MEDIUM')
        self.assertEqual(result['working_threads'], ['s1'])

    def test_close_is_harmless(self):
        source = QoderCnSource(self.root, self.app_data)
        source.close()
        source.close()


class SourceSelectionTests(unittest.TestCase):
    def test_qoder_combinations_are_enabled(self):
        self.assertIn('qodercn', NAMES)
        self.assertIn('qodercn', CHOICES)
        self.assertEqual(enabled_sources('qodercn'), ('qodercn',))
        self.assertEqual(enabled_sources('codex,qodercn'), ('codex', 'qodercn'))
        self.assertEqual(enabled_sources('qodercn,dsh'), ('qodercn', 'dsh'))

    def test_legacy_aliases_still_work(self):
        self.assertEqual(enabled_sources('both'), ('codex', 'workbuddy'))
        # Upgrading an existing 'all' install must not add an uninitialized source.
        self.assertEqual(enabled_sources('all'), ('codex', 'workbuddy', 'dsh'))

    def test_selection_prefers_canonical_names(self):
        self.assertEqual(selection_for({'qodercn'}), 'qodercn')
        self.assertEqual(selection_for({'codex', 'qodercn'}), 'codex,qodercn')
        self.assertEqual(selection_for({'codex', 'workbuddy'}), 'both')
        self.assertEqual(selection_for({'codex', 'workbuddy', 'dsh'}), 'all')
        self.assertEqual(selection_for(set(NAMES)), 'codex,workbuddy,dsh,qodercn')

    def test_unknown_or_duplicate_sources_are_rejected(self):
        for value in ('nope', 'qodercn,nope', 'qodercn,qodercn', ''):
            with self.assertRaises(ValueError):
                enabled_sources(value)


if __name__ == '__main__':
    unittest.main()